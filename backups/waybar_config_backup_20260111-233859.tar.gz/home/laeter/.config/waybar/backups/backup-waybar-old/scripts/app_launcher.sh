#!/bin/bash

$HOME/.config/rofi/launchers/type-4/launcher.sh
